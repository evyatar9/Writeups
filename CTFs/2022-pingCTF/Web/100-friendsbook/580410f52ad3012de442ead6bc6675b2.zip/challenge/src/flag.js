export const FLAG =
	"ping{FAKE_FLAG}";
